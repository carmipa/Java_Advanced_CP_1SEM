package br.com.fiap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSemestralApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSemestralApplication.class, args);
	}

}
