package br.com.fiap.cp1_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cp1BankApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cp1BankApplication.class, args);
	}

}
